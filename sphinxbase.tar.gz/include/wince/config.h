/* Keep only one configuration file */

#include "sphinx_config.h"
